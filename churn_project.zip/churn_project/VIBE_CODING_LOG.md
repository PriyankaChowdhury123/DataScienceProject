# Vibe Coding Log (1 page) — ChurnGuard AI

**Team:** ______  **Course:** Data Science for Managers  **Dates:** ______

## 1. Platforms & roles
| Tool | Used for | Who |
|---|---|---|
| (e.g. Claude / Claude Cowork) | scaffolding repo, Streamlit UI, docs | |
| (e.g. GitHub Copilot / Codex in VS Code) | autocomplete, refactors, tests | |
| (e.g. Google AI Studio / Antigravity) | alternative model comparison, UI iteration | |

## 2. Prompt-engineering strategies that worked
1. **Spec-first prompts:** gave schema, goal metric (PR-AUC), and constraints ("no data leakage; all fitting inside Pipeline").
2. **Role + format:** "Act as a senior ML engineer; return a modular file with docstrings."
3. **Small, verifiable steps:** one module per prompt (data → model → roi → explain → app), run after each.
4. **Ask for the WHY:** "Explain each hyper-parameter range" -> became our Q&A notes.

## 3. Agentic workflow
(Describe: e.g., agent generated first draft -> humans ran tests -> pasted traceback back -> agent fixed. Note parallel tasks.)

## 4. Where AI was wrong & what humans fixed
| Issue | How we caught it | Fix |
|---|---|---|
| (e.g. scaler fitted before split) | code review | moved into Pipeline |
| (e.g. optimised accuracy) | imbalance analysis | switched to PR-AUC + $ threshold |

## 5. Human-owned decisions (we can defend these)
Problem scoping, cost assumptions, metric choice, threshold logic, feature choices, explainability design.

## 6. Lessons learned
(2-3 bullets.)
