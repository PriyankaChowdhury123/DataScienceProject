"""ChurnGuard AI - executive web app.   Run:  streamlit run app.py"""
import json

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st

from src import config, data, explain, roi

st.set_page_config(page_title="ChurnGuard AI", page_icon="📉", layout="wide")


@st.cache_resource
def load_artifacts():
    pipe = joblib.load(config.MODEL_PATH)
    meta = json.loads(config.META_PATH.read_text())
    background = joblib.load(config.BACKGROUND_PATH)
    return pipe, meta, explain.build_explainer(pipe, background)


@st.cache_data
def load_test_predictions():
    return pd.read_csv(config.REPORTS_DIR / "test_predictions.csv")


if not config.MODEL_PATH.exists():
    st.error("No trained model found. Run `python train.py` first.")
    st.stop()

pipe, meta, explainer = load_artifacts()
schema = meta["schema"]["categorical"]
threshold = meta["threshold"]

# ------------------------------ sidebar ------------------------------------
st.sidebar.title("📉 ChurnGuard AI")
st.sidebar.caption("Predict who will leave, why, and what a retention offer is worth.")
st.sidebar.subheader("Business assumptions")
clv = st.sidebar.number_input("Value kept if customer is saved ($)", 100.0, 10000.0,
                              float(meta["costs"]["clv"]), 50.0)
offer_cost = st.sidebar.number_input("Cost of one retention offer ($)", 1.0, 1000.0,
                                     float(meta["costs"]["offer_cost"]), 5.0)
success = st.sidebar.slider("Offer success rate", 0.05, 0.9,
                            float(meta["costs"]["success_rate"]), 0.05)
costs = roi.CostParams(clv, offer_cost, success)
st.sidebar.info(f"Model: **{meta['model_name']}**\n\nDecision threshold: **{threshold:.2f}** "
                "(chosen to maximise dollars, not accuracy)")


def risk_band(p):
    if p >= threshold:
        return "HIGH", "🔴"
    return ("MEDIUM", "🟠") if p >= threshold / 2 else ("LOW", "🟢")


def score(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["churn_probability"] = pipe.predict_proba(df)[:, 1]
    out["risk"] = out["churn_probability"].map(lambda p: risk_band(p)[0])
    out["expected_value_of_offer"] = out["churn_probability"] * success * clv - offer_cost
    out["contact"] = np.where(out["churn_probability"] >= threshold, "Yes", "No")
    return out


tab1, tab2, tab3, tab4 = st.tabs(["🔍 Score a customer", "📋 Batch scoring",
                                  "💰 Business impact", "🧪 Model performance"])

# ---------------------------- tab 1: single --------------------------------
with tab1:
    st.header("Score one customer")
    c1, c2, c3 = st.columns(3)
    with c1:
        st.subheader("Account")
        tenure = st.slider("Tenure (months)", 0, 72, 12)
        contract = c1.selectbox("Contract", schema["Contract"])
        monthly = st.slider("Monthly charge ($)", 18.0, 120.0, 70.0, 0.5)
        paperless = c1.selectbox("Paperless billing", schema["PaperlessBilling"])
        payment = c1.selectbox("Payment method", schema["PaymentMethod"])
    with c2:
        st.subheader("Household")
        senior = int(st.checkbox("Senior citizen"))
        partner = c2.selectbox("Has partner", schema["Partner"])
        dependents = c2.selectbox("Has dependents", schema["Dependents"])
        phone = c2.selectbox("Phone service", schema["PhoneService"])
        lines_opts = ["No phone service"] if phone == "No" else [o for o in schema["MultipleLines"] if o != "No phone service"]
        lines = c2.selectbox("Multiple lines", lines_opts)
    with c3:
        st.subheader("Internet & add-ons")
        internet = c3.selectbox("Internet service", schema["InternetService"])
        no_net = internet == "No"
        addon_vals = {}
        for col in data.ADDON_COLS:
            opts = ["No internet service"] if no_net else ["No", "Yes"]
            addon_vals[col] = c3.selectbox(explain.label(col), opts)

    row = pd.DataFrame([{
        "SeniorCitizen": senior, "Partner": partner, "Dependents": dependents, "tenure": tenure,
        "PhoneService": phone, "MultipleLines": lines, "InternetService": internet, **addon_vals,
        "Contract": contract, "PaperlessBilling": paperless, "PaymentMethod": payment,
        "MonthlyCharges": monthly, "TotalCharges": round(monthly * tenure, 2)}])[data.RAW_INPUT_COLS]

    if st.button("Predict churn risk", type="primary"):
        res = score(row).iloc[0]
        p = float(res["churn_probability"])
        band, icon = risk_band(p)
        m1, m2, m3 = st.columns(3)
        m1.metric("Churn probability", f"{p:.1%}")
        m2.metric("Risk level", f"{icon} {band}")
        m3.metric("Expected value of an offer", f"${res['expected_value_of_offer']:,.0f}")
        st.progress(min(p, 1.0))
        if p >= threshold:
            st.warning(f"**Recommended action:** contact this customer with a retention offer "
                       f"(positive expected value: ${res['expected_value_of_offer']:,.0f}).")
        else:
            st.success("**Recommended action:** no offer needed - below the profit-maximising threshold.")
        reasons = explain.local_reasons(pipe, explainer, row, top_k=7)
        st.subheader("Why? Top drivers of this prediction")
        fig, ax = plt.subplots(figsize=(7, 3.5))
        r = reasons[::-1]
        ax.barh(r["driver"], r["impact"], color=np.where(r["impact"] > 0, "#d62728", "#2ca02c"))
        ax.axvline(0, color="k", lw=0.8)
        ax.set_xlabel("← lowers risk      |      raises risk →  (SHAP, log-odds)")
        st.pyplot(fig)
        st.caption("Red bars push the customer toward leaving; green bars push toward staying.")

# ---------------------------- tab 2: batch ---------------------------------
with tab2:
    st.header("Score a customer list")
    st.write("Upload a CSV with these columns (or use the sample):")
    st.code(", ".join(data.RAW_INPUT_COLS), language=None)
    up = st.file_uploader("CSV file", type="csv")
    use_sample = st.checkbox("Use 200 sample customers from the held-out test set")
    batch = None
    if up is not None:
        batch = pd.read_csv(up)
    elif use_sample:
        batch = load_test_predictions().head(200)
    if batch is not None:
        missing = [c for c in data.RAW_INPUT_COLS if c not in batch.columns]
        if missing:
            st.error(f"Missing columns: {missing}")
        else:
            out = score(batch).sort_values("churn_probability", ascending=False)
            n_contact = int((out["contact"] == "Yes").sum())
            a, b, c = st.columns(3)
            a.metric("Customers scored", len(out))
            b.metric("Recommended to contact", n_contact)
            c.metric("Expected net value", f"${out.loc[out.contact == 'Yes', 'expected_value_of_offer'].sum():,.0f}")
            show = ["churn_probability", "risk", "contact", "expected_value_of_offer",
                    "tenure", "Contract", "MonthlyCharges", "InternetService"]
            st.dataframe(out[show].style.format({"churn_probability": "{:.1%}",
                                                 "expected_value_of_offer": "${:,.0f}"}),
                         width="stretch", height=420)
            st.download_button("Download ranked list", out.to_csv(index=False).encode(),
                               "churn_scores.csv", "text/csv")

# ---------------------------- tab 3: ROI -----------------------------------
with tab3:
    st.header("Business impact (held-out test customers)")
    tp = load_test_predictions()
    base = st.number_input("Customers in your campaign cycle", 1000, 10_000_000,
                           config.DEFAULT_CUSTOMER_BASE, 1000)
    thr = st.slider("Decision threshold", 0.05, 0.95, float(threshold), 0.01)
    s = roi.roi_summary(tp["y_true"], tp["proba"], thr, costs)
    scale = base / s["n_customers"]
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Net benefit (model)", f"${s['net_benefit_model'] * scale:,.0f}")
    k2.metric("Campaign spend", f"${s['campaign_spend'] * scale:,.0f}")
    k3.metric("ROI on spend", f"{s['roi_pct']:.0f}%")
    k4.metric("Churners reached", f"{s['churners_caught_pct']:.0f}%")
    comp = pd.DataFrame({
        "Strategy": ["Do nothing", "Contact everyone", "Random (same volume)", "AI model"],
        "Net benefit ($)": [0, s["net_benefit_contact_all"] * scale,
                            s["net_benefit_random_same_volume"] * scale, s["net_benefit_model"] * scale]})
    st.bar_chart(comp.set_index("Strategy"))
    th, val = roi.benefit_curve(tp["y_true"], tp["proba"], costs)
    st.subheader("Net benefit by threshold")
    st.line_chart(pd.DataFrame({"net benefit ($)": val * scale}, index=th))
    st.caption(f"Best threshold under the current assumptions: **{th[int(np.argmax(val))]:.2f}**. "
               "Results scale from the test set to your customer base - treat as estimates.")

# ---------------------------- tab 4: performance ---------------------------
with tab4:
    st.header("Model performance & explainability")
    tm = meta["test_metrics_at_business_threshold"]
    cols = st.columns(5)
    for col, (k, lab) in zip(cols, [("roc_auc", "ROC-AUC"), ("pr_auc", "PR-AUC"), ("recall", "Recall"),
                                    ("precision", "Precision"), ("f1", "F1")]):
        col.metric(lab, f"{tm[k]:.3f}")
    st.subheader("Cross-validation (5-fold, training data)")
    st.dataframe(pd.DataFrame(meta["cv_default"]), width="stretch")
    st.subheader("Tuned models (PR-AUC)")
    st.dataframe(pd.DataFrame(meta["cv_tuned"]), width="stretch")
    for img in ["shap_importance.png", "shap_summary.png", "roc_pr.png", "confusion_matrix.png", "calibration.png"]:
        p = config.REPORTS_DIR / img
        if p.exists():
            st.image(str(p))
    seg = config.REPORTS_DIR / "error_by_segment.csv"
    if seg.exists():
        st.subheader("Error analysis by segment")
        st.dataframe(pd.read_csv(seg), width="stretch")
