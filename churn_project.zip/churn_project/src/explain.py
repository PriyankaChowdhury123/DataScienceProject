"""Explainability layer (SHAP) with business-friendly aggregation.

SHAP assigns each feature a contribution (in log-odds) to one prediction.
One-hot encoding splits a single business feature (e.g. Contract) into several
columns, so we SUM SHAP values back to the ORIGINAL feature for executives.
"""
import numpy as np
import pandas as pd
import shap
from sklearn.linear_model import LogisticRegression

from .data import CATEGORICAL

LABELS = {
    "tenure": "Tenure (months)", "MonthlyCharges": "Monthly charge ($)",
    "TotalCharges": "Total charges ($)", "avg_monthly_spend": "Avg monthly spend ($)",
    "charge_delta": "Price change vs history ($)", "num_addons": "Number of add-ons",
    "SeniorCitizen": "Senior citizen", "InternetService": "Internet service",
    "PaymentMethod": "Payment method", "PaperlessBilling": "Paperless billing",
    "tenure_group": "Tenure band", "autopay": "Automatic payment",
    "OnlineSecurity": "Online security", "OnlineBackup": "Online backup",
    "DeviceProtection": "Device protection", "TechSupport": "Tech support",
    "StreamingTV": "Streaming TV", "StreamingMovies": "Streaming movies",
    "MultipleLines": "Multiple lines", "PhoneService": "Phone service",
}


def label(col: str) -> str:
    return LABELS.get(col, col)


def feature_names(pipe) -> list:
    return list(pipe.named_steps["prep"].get_feature_names_out())


def original_column(name: str) -> str:
    """'cat__Contract_One year' -> 'Contract';  'num__tenure' -> 'tenure'."""
    kind, _, rest = name.partition("__")
    if kind == "num":
        return rest
    for col in CATEGORICAL:
        if rest.startswith(col + "_"):
            return col
    return rest


def transform(pipe, X: pd.DataFrame) -> np.ndarray:
    """Run every pipeline step except the final classifier."""
    return pipe[:-1].transform(X)


def build_explainer(pipe, background: pd.DataFrame):
    clf = pipe.named_steps["clf"]
    if isinstance(clf, LogisticRegression):
        return shap.LinearExplainer(clf, transform(pipe, background))
    return shap.TreeExplainer(clf)


def shap_matrix(explainer, Xt: np.ndarray) -> np.ndarray:
    """Return SHAP values for the positive (churn) class as (n, features)."""
    sv = explainer.shap_values(Xt)
    if isinstance(sv, list):          # older shap: one array per class
        sv = sv[1]
    sv = np.asarray(sv)
    if sv.ndim == 3:                  # newer shap: (n, features, classes)
        sv = sv[..., 1]
    return sv


def aggregate_by_feature(pipe, sv: np.ndarray) -> pd.DataFrame:
    """Sum one-hot SHAP columns back to original features -> (n, n_features)."""
    cols = [original_column(n) for n in feature_names(pipe)]
    return pd.DataFrame(sv, columns=cols).T.groupby(level=0).sum().T


def global_importance(pipe, sv: np.ndarray) -> pd.Series:
    """Mean |SHAP| per original business feature (for the exec slide)."""
    agg = aggregate_by_feature(pipe, sv)
    return agg.abs().mean().sort_values(ascending=False)


def local_reasons(pipe, explainer, row: pd.DataFrame, top_k: int = 6) -> pd.DataFrame:
    """Top drivers for ONE customer: label, actual value, SHAP impact."""
    sv = shap_matrix(explainer, transform(pipe, row))
    agg = aggregate_by_feature(pipe, sv).iloc[0]
    fe_row = pipe.named_steps["features"].transform(row).iloc[0]
    out = []
    for col, impact in agg.items():
        val = fe_row.get(col, "")
        if isinstance(val, (int, float, np.integer, np.floating)):
            val = f"{val:.4g}"
        out.append({"driver": f"{label(col)} = {val}", "impact": float(impact)})
    df = pd.DataFrame(out)
    df = df.reindex(df["impact"].abs().sort_values(ascending=False).index)
    return df.head(top_k).reset_index(drop=True)
