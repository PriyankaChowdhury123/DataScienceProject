"""Business / ROI layer: converts model predictions into dollars.

Economics of a retention campaign (per customer we CONTACT):
  * contacted churner (TP):      + success_rate * CLV - offer_cost
  * contacted non-churner (FP):  - offer_cost   (money wasted)
  * not contacted (TN / FN):       0            (baseline: do nothing)
"""
from dataclasses import dataclass, asdict

import numpy as np


@dataclass
class CostParams:
    clv: float
    offer_cost: float
    success_rate: float

    def as_dict(self):
        return asdict(self)


def confusion_counts(y_true, y_pred):
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    tp = int(((y_true == 1) & (y_pred == 1)).sum())
    fp = int(((y_true == 0) & (y_pred == 1)).sum())
    fn = int(((y_true == 1) & (y_pred == 0)).sum())
    tn = int(((y_true == 0) & (y_pred == 0)).sum())
    return tp, fp, fn, tn


def net_benefit(y_true, y_pred, p: CostParams) -> float:
    tp, fp, _, _ = confusion_counts(y_true, y_pred)
    return tp * (p.success_rate * p.clv - p.offer_cost) - fp * p.offer_cost


def benefit_curve(y_true, proba, p: CostParams, thresholds=None):
    """Net benefit for every candidate decision threshold."""
    if thresholds is None:
        thresholds = np.round(np.arange(0.05, 0.96, 0.01), 2)
    values = [net_benefit(y_true, (proba >= t).astype(int), p) for t in thresholds]
    return np.asarray(thresholds), np.asarray(values)


def best_threshold(y_true, proba, p: CostParams) -> float:
    """Threshold that maximises dollar benefit (not accuracy!)."""
    thresholds, values = benefit_curve(y_true, proba, p)
    return float(thresholds[int(np.argmax(values))])


def roi_summary(y_true, proba, threshold: float, p: CostParams) -> dict:
    """Compare our model against simple alternative strategies."""
    y_true = np.asarray(y_true)
    proba = np.asarray(proba)
    n = len(y_true)
    pred = (proba >= threshold).astype(int)
    tp, fp, fn, tn = confusion_counts(y_true, pred)
    contacted = tp + fp
    spend = contacted * p.offer_cost
    benefit = net_benefit(y_true, pred, p)

    pos, neg = int(y_true.sum()), int(n - y_true.sum())
    gain_tp = p.success_rate * p.clv - p.offer_cost
    contact_all = pos * gain_tp - neg * p.offer_cost
    prevalence = pos / n
    # random targeting of the same number of customers
    random_same = contacted * (prevalence * gain_tp - (1 - prevalence) * p.offer_cost)

    return {
        "n_customers": n,
        "threshold": float(threshold),
        "contacted": contacted,
        "true_positives": tp, "false_positives": fp,
        "false_negatives": fn, "true_negatives": tn,
        "campaign_spend": float(spend),
        "net_benefit_model": float(benefit),
        "net_benefit_contact_all": float(contact_all),
        "net_benefit_random_same_volume": float(random_same),
        "net_benefit_do_nothing": 0.0,
        "roi_pct": float(benefit / spend * 100) if spend else 0.0,
        "benefit_per_customer": float(benefit / n),
        "churners_caught_pct": float(tp / pos * 100) if pos else 0.0,
    }
