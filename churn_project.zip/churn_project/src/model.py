"""Modelling layer: candidates, cross-validation, tuning, evaluation."""
import numpy as np
import pandas as pd
from scipy.stats import loguniform, randint, uniform
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, average_precision_score, brier_score_loss,
                             f1_score, precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import (RandomizedSearchCV, StratifiedKFold,
                                     cross_val_predict, cross_validate)
from sklearn.pipeline import Pipeline
from xgboost import XGBClassifier

from . import config, data

SCORING = {"roc_auc": "roc_auc", "pr_auc": "average_precision",
           "f1": "f1", "recall": "recall", "precision": "precision"}


def cv_splitter():
    return StratifiedKFold(n_splits=config.CV_FOLDS, shuffle=True,
                           random_state=config.RANDOM_STATE)


def make_pipeline(clf) -> Pipeline:
    return Pipeline([*data.build_feature_steps(), ("clf", clf)])


def candidate_models(y_train) -> dict:
    """Baseline -> stronger models. Imbalance handled via class weights."""
    pos = int(np.sum(y_train))
    spw = (len(y_train) - pos) / pos           # scale_pos_weight = neg / pos
    rs = config.RANDOM_STATE
    return {
        "Dummy (prior)": DummyClassifier(strategy="prior"),
        "Logistic Regression": LogisticRegression(
            max_iter=2000, class_weight="balanced", random_state=rs),
        "Random Forest": RandomForestClassifier(
            n_estimators=300, class_weight="balanced_subsample",
            n_jobs=1, random_state=rs),
        "XGBoost": XGBClassifier(
            n_estimators=300, learning_rate=0.05, max_depth=4, subsample=0.8,
            colsample_bytree=0.8, scale_pos_weight=spw, eval_metric="logloss",
            tree_method="hist", n_jobs=1, random_state=rs),
    }


# Hyper-parameter search spaces (every range has a reason -> see docs/QA_PREP.md)
SEARCH_SPACES = {
    "Logistic Regression": {"clf__C": loguniform(1e-3, 1e2)},   # L2 (default) strength
    "Random Forest": {"clf__n_estimators": randint(100, 300),
                      "clf__max_depth": [4, 6, 8, 12, None],
                      "clf__min_samples_leaf": randint(1, 20),
                      "clf__max_features": ["sqrt", "log2", 0.5]},
    "XGBoost": {"clf__n_estimators": randint(100, 400),
                "clf__learning_rate": loguniform(0.01, 0.2),
                "clf__max_depth": randint(2, 7),
                "clf__min_child_weight": randint(1, 10),
                "clf__subsample": uniform(0.6, 0.4),
                "clf__colsample_bytree": uniform(0.5, 0.5),
                "clf__reg_lambda": loguniform(0.1, 20)},
}


def cross_validate_models(models: dict, X, y) -> pd.DataFrame:
    """Mean +/- std of each metric across stratified folds."""
    rows = []
    for name, clf in models.items():
        res = cross_validate(make_pipeline(clf), X, y, cv=cv_splitter(),
                             scoring=SCORING, n_jobs=-1)
        row = {"model": name}
        for m in SCORING:
            vals = res[f"test_{m}"]
            row[m] = f"{vals.mean():.3f} ± {vals.std():.3f}"
            row[f"{m}_mean"] = float(vals.mean())
        rows.append(row)
    return pd.DataFrame(rows)


def tune_model(name: str, clf, X, y):
    """Randomised search optimising PR-AUC (right metric for imbalanced churn)."""
    search = RandomizedSearchCV(
        make_pipeline(clf), SEARCH_SPACES[name], n_iter=config.N_ITER_SEARCH,
        scoring="average_precision", cv=cv_splitter(), n_jobs=-1,
        random_state=config.RANDOM_STATE, refit=True)
    search.fit(X, y)
    return search


def out_of_fold_proba(estimator, X, y) -> np.ndarray:
    """Honest probabilities for training rows (each predicted by a model that
    never saw it). Used to choose the business threshold without touching test."""
    return cross_val_predict(estimator, X, y, cv=cv_splitter(),
                             method="predict_proba", n_jobs=-1)[:, 1]


def evaluate(y_true, proba, threshold: float) -> dict:
    pred = (np.asarray(proba) >= threshold).astype(int)
    return {
        "roc_auc": roc_auc_score(y_true, proba),
        "pr_auc": average_precision_score(y_true, proba),
        "brier": brier_score_loss(y_true, proba),
        "threshold": float(threshold),
        "accuracy": accuracy_score(y_true, pred),
        "precision": precision_score(y_true, pred, zero_division=0),
        "recall": recall_score(y_true, pred),
        "f1": f1_score(y_true, pred),
    }


def error_analysis(X_test: pd.DataFrame, y_true, proba, threshold: float) -> pd.DataFrame:
    """Error rates by business segment -> where does the model struggle?"""
    df = X_test.copy()
    df["y_true"], df["proba"] = np.asarray(y_true), np.asarray(proba)
    df["pred"] = (df["proba"] >= threshold).astype(int)
    df["tenure_group"] = data.add_features(df)["tenure_group"]
    rows = []
    for seg in ["Contract", "InternetService", "PaymentMethod", "tenure_group"]:
        for val, g in df.groupby(seg):
            pos, neg = (g.y_true == 1).sum(), (g.y_true == 0).sum()
            rows.append({
                "segment": seg, "value": val, "n": len(g),
                "churn_rate": g.y_true.mean(),
                "recall": ((g.pred == 1) & (g.y_true == 1)).sum() / pos if pos else np.nan,
                "false_positive_rate": ((g.pred == 1) & (g.y_true == 0)).sum() / neg if neg else np.nan,
            })
    return pd.DataFrame(rows)
