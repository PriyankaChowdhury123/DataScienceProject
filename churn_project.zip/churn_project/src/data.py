"""Data layer: loading, cleaning, feature engineering and preprocessing.

Design rule: ALL transformations that learn from data (imputation values,
scaling parameters, category lists) live inside a scikit-learn Pipeline so
they are fitted on training folds only -> no data leakage.
"""
import urllib.request

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler

from . import config

ADDON_COLS = ["OnlineSecurity", "OnlineBackup", "DeviceProtection",
              "TechSupport", "StreamingTV", "StreamingMovies"]

# Final model inputs (after feature engineering).
# 'gender' and 'customerID' are deliberately NOT used (fairness / no signal).
NUMERIC = ["tenure", "MonthlyCharges", "TotalCharges", "avg_monthly_spend",
           "charge_delta", "num_addons", "SeniorCitizen"]
CATEGORICAL = ["Partner", "Dependents", "PhoneService", "MultipleLines",
               "InternetService", *ADDON_COLS, "Contract", "PaperlessBilling",
               "PaymentMethod", "tenure_group", "autopay"]
# Columns a user must supply (raw, before feature engineering)
RAW_INPUT_COLS = ["SeniorCitizen", "Partner", "Dependents", "tenure",
                  "PhoneService", "MultipleLines", "InternetService", *ADDON_COLS,
                  "Contract", "PaperlessBilling", "PaymentMethod",
                  "MonthlyCharges", "TotalCharges"]


def download_data(force: bool = False):
    """Download the public IBM Telco churn dataset if not present."""
    if config.DATA_PATH.exists() and not force:
        return config.DATA_PATH
    config.DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    urllib.request.urlretrieve(config.DATA_URL, config.DATA_PATH)
    return config.DATA_PATH


def load_raw() -> pd.DataFrame:
    download_data()
    return pd.read_csv(config.DATA_PATH)


def clean(df: pd.DataFrame) -> pd.DataFrame:
    """Row-level cleaning that does not learn anything from the data."""
    df = df.copy()
    df = df.drop_duplicates()
    if "customerID" in df.columns:
        df = df.drop(columns="customerID")
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    df[config.TARGET] = (df[config.TARGET].astype(str).str.strip() == "Yes").astype(int)
    return df


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    """Feature engineering (stateless, so it is safe inside the pipeline).

    - TotalCharges blanks occur only for tenure == 0 -> tenure * monthly (=0).
    - avg_monthly_spend / charge_delta capture price increases over time.
    - num_addons counts protective / entertainment add-ons.
    - tenure_group gives linear models a non-linear view of tenure.
    - autopay flags automatic payment methods (lower friction).
    """
    df = df.copy()
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    df["TotalCharges"] = df["TotalCharges"].fillna(df["MonthlyCharges"] * df["tenure"])
    df["avg_monthly_spend"] = df["TotalCharges"] / df["tenure"].clip(lower=1)
    df["charge_delta"] = df["MonthlyCharges"] - df["avg_monthly_spend"]
    df["num_addons"] = (df[ADDON_COLS] == "Yes").sum(axis=1)
    df["tenure_group"] = pd.cut(
        df["tenure"], bins=[-1, 12, 24, 48, 72, 10_000],
        labels=["0-12", "13-24", "25-48", "49-72", "73+"]).astype(str)
    df["autopay"] = np.where(
        df["PaymentMethod"].astype(str).str.contains("automatic"), "Yes", "No")
    return df


def build_preprocessor() -> ColumnTransformer:
    numeric = Pipeline([("impute", SimpleImputer(strategy="median")),
                        ("scale", StandardScaler())])
    categorical = Pipeline([
        ("impute", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False))])
    return ColumnTransformer(
        [("num", numeric, NUMERIC), ("cat", categorical, CATEGORICAL)],
        remainder="drop", sparse_threshold=0)


def build_feature_steps():
    """Pipeline steps shared by every model: features -> preprocessing."""
    return [("features", FunctionTransformer(add_features, validate=False)),
            ("prep", build_preprocessor())]


def get_train_test():
    """Load, clean and make a STRATIFIED train/test split (before any fitting)."""
    df = clean(load_raw())
    X, y = df.drop(columns=config.TARGET), df[config.TARGET]
    return train_test_split(X, y, test_size=config.TEST_SIZE,
                            stratify=y, random_state=config.RANDOM_STATE)


def input_schema(X: pd.DataFrame) -> dict:
    """Describe valid inputs so the app can build its form automatically."""
    schema = {"categorical": {}, "numeric": {}}
    for col in CATEGORICAL:
        if col in X.columns:
            schema["categorical"][col] = sorted(X[col].dropna().unique().tolist())
    for col in ["tenure", "MonthlyCharges"]:
        schema["numeric"][col] = {"min": float(X[col].min()), "max": float(X[col].max()),
                                  "median": float(X[col].median())}
    return schema
