"""Central configuration: paths, seeds and default business assumptions.

Keeping every 'magic number' here means the whole team can see (and defend)
each assumption in one place.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = ROOT / "data" / "telco_churn.csv"
DATA_URL = (
    "https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/"
    "master/data/Telco-Customer-Churn.csv"
)
MODEL_DIR = ROOT / "models"
REPORTS_DIR = ROOT / "reports"
MODEL_PATH = MODEL_DIR / "churn_pipeline.joblib"
BACKGROUND_PATH = MODEL_DIR / "shap_background.joblib"
META_PATH = MODEL_DIR / "metadata.json"

RANDOM_STATE = 42
TEST_SIZE = 0.20
CV_FOLDS = 5
N_ITER_SEARCH = 12          # random-search iterations per model
TARGET = "Churn"

# ---- Business assumptions (all editable in the app) ----------------------
# CLV  : revenue we keep if a would-be churner is saved
#        (~12 months x ~$65 average monthly bill, rounded)
# COST : cost of one retention offer (discount / call / credit)
# SUCCESS: share of contacted churners the offer actually retains
DEFAULT_CLV = 800.0
DEFAULT_OFFER_COST = 50.0
DEFAULT_SUCCESS_RATE = 0.30
DEFAULT_CUSTOMER_BASE = 10_000   # customers scored per campaign cycle
