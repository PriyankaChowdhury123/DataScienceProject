"""End-to-end training script.   Run:  python train.py

Steps: split -> CV all models -> tune -> choose threshold on out-of-fold
predictions (business $) -> evaluate ONCE on the test set -> SHAP -> save.
"""
import json
import time
import warnings

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap
import sklearn
import xgboost
from sklearn.calibration import calibration_curve
from sklearn.metrics import (ConfusionMatrixDisplay, PrecisionRecallDisplay,
                             RocCurveDisplay)

from src import config, data, explain, model, roi

warnings.filterwarnings("ignore")


def save_fig(name):
    plt.tight_layout()
    plt.savefig(config.REPORTS_DIR / name, dpi=150, bbox_inches="tight")
    plt.close()


def main():
    t0 = time.time()
    config.MODEL_DIR.mkdir(exist_ok=True)
    config.REPORTS_DIR.mkdir(exist_ok=True)
    costs = roi.CostParams(config.DEFAULT_CLV, config.DEFAULT_OFFER_COST,
                           config.DEFAULT_SUCCESS_RATE)

    # 1. Split FIRST (test set stays untouched until step 6)
    X_train, X_test, y_train, y_test = data.get_train_test()
    print(f"Train {X_train.shape}, Test {X_test.shape}, churn rate {y_train.mean():.1%}")

    # 2. Cross-validate baseline + candidate models with default parameters
    models = model.candidate_models(y_train)
    cv_default = model.cross_validate_models(models, X_train, y_train)
    print("\nCross-validation (defaults):\n", cv_default[["model", "roc_auc", "pr_auc", "f1", "recall", "precision"]].to_string(index=False))

    # 3. Tune each real model, optimising PR-AUC
    tuned, rows = {}, []
    for name in ["Logistic Regression", "Random Forest", "XGBoost"]:
        print(f"\nTuning {name} ...")
        search = model.tune_model(name, models[name], X_train, y_train)
        tuned[name] = search
        rows.append({"model": name, "cv_pr_auc_tuned": search.best_score_,
                     "best_params": {k.replace("clf__", ""): (float(v) if isinstance(v, (np.floating, float)) else (int(v) if isinstance(v, (np.integer,)) else v))
                                     for k, v in search.best_params_.items()}})
        print(f"  best CV PR-AUC {search.best_score_:.4f}")
    tuned_df = pd.DataFrame(rows).sort_values("cv_pr_auc_tuned", ascending=False)
    best_name = tuned_df.iloc[0]["model"]
    best_pipe = tuned[best_name].best_estimator_
    print(f"\nSelected model: {best_name}")

    # 4. Business threshold from OUT-OF-FOLD train predictions (no test peeking)
    oof = model.out_of_fold_proba(best_pipe, X_train, y_train)
    threshold = roi.best_threshold(y_train, oof, costs)
    print(f"Profit-maximising threshold: {threshold:.2f}")

    # 5. Final fit on the full training set, 6. evaluate ONCE on the test set
    best_pipe.fit(X_train, y_train)
    proba = best_pipe.predict_proba(X_test)[:, 1]
    test_metrics = model.evaluate(y_test, proba, 0.5)
    test_metrics_biz = model.evaluate(y_test, proba, threshold)
    summary = roi.roi_summary(y_test, proba, threshold, costs)
    print("\nTest metrics @0.5      :", {k: round(v, 3) for k, v in test_metrics.items()})
    print("Test metrics @business :", {k: round(v, 3) for k, v in test_metrics_biz.items()})
    print("ROI summary:", {k: round(v, 1) if isinstance(v, float) else v for k, v in summary.items()})

    # 7. Error analysis
    seg = model.error_analysis(X_test, y_test, proba, threshold)
    seg.to_csv(config.REPORTS_DIR / "error_by_segment.csv", index=False)
    errs = X_test.copy(); errs["y_true"] = y_test.values; errs["proba"] = proba
    errs["pred"] = (proba >= threshold).astype(int)
    errs[(errs.pred != errs.y_true)].assign(
        confidence_gap=lambda d: (d.proba - threshold).abs()
    ).sort_values("confidence_gap", ascending=False).head(10).to_csv(
        config.REPORTS_DIR / "top_misclassified.csv", index=False)
    errs.to_csv(config.REPORTS_DIR / "test_predictions.csv", index=False)

    # 8. Plots
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    RocCurveDisplay.from_predictions(y_test, proba, ax=ax[0]); ax[0].set_title("ROC curve")
    PrecisionRecallDisplay.from_predictions(y_test, proba, ax=ax[1]); ax[1].set_title("Precision-Recall curve")
    save_fig("roc_pr.png")
    ConfusionMatrixDisplay.from_predictions(y_test, (proba >= threshold).astype(int),
                                            display_labels=["Stay", "Churn"], cmap="Blues")
    plt.title(f"Confusion matrix @ threshold {threshold:.2f}"); save_fig("confusion_matrix.png")
    frac, mean_pred = calibration_curve(y_test, proba, n_bins=10)
    plt.plot(mean_pred, frac, "o-", label=best_name); plt.plot([0, 1], [0, 1], "k--", label="Perfect")
    plt.xlabel("Predicted probability"); plt.ylabel("Observed churn rate")
    plt.title("Calibration"); plt.legend(); save_fig("calibration.png")
    th, val = roi.benefit_curve(y_test, proba, costs)
    plt.plot(th, val); plt.axvline(threshold, color="r", ls="--", label=f"chosen = {threshold:.2f}")
    plt.xlabel("Decision threshold"); plt.ylabel("Net benefit on test set ($)")
    plt.title("Business value vs threshold"); plt.legend(); save_fig("net_benefit_curve.png")

    # 9. SHAP (global)
    background = X_train.sample(200, random_state=config.RANDOM_STATE)
    explainer = explain.build_explainer(best_pipe, background)
    sample = X_test.sample(min(500, len(X_test)), random_state=config.RANDOM_STATE)
    Xt = explain.transform(best_pipe, sample)
    sv = explain.shap_matrix(explainer, Xt)
    names = [n.split("__", 1)[1] for n in explain.feature_names(best_pipe)]
    shap.summary_plot(sv, pd.DataFrame(Xt, columns=names), show=False, max_display=15)
    plt.title("SHAP summary (each dot = one customer)"); save_fig("shap_summary.png")
    imp = explain.global_importance(best_pipe, sv).head(12)[::-1]
    imp.index = [explain.label(i) for i in imp.index]
    imp.plot.barh(color="#1f77b4", figsize=(7, 5)); plt.xlabel("Mean |SHAP| (log-odds)")
    plt.title("What drives churn risk?"); save_fig("shap_importance.png")

    # 10. Persist everything the app needs
    joblib.dump(best_pipe, config.MODEL_PATH)
    joblib.dump(background, config.BACKGROUND_PATH)
    meta = {
        "model_name": best_name, "threshold": threshold, "costs": costs.as_dict(),
        "best_params": tuned_df.set_index("model")["best_params"].to_dict(),
        "cv_default": cv_default.drop(columns=[c for c in cv_default if c.endswith("_mean")]).to_dict("records"),
        "cv_tuned": tuned_df[["model", "cv_pr_auc_tuned"]].to_dict("records"),
        "test_metrics_at_0.5": test_metrics, "test_metrics_at_business_threshold": test_metrics_biz,
        "roi_summary": summary, "schema": data.input_schema(X_train),
        "versions": {"sklearn": sklearn.__version__, "xgboost": xgboost.__version__, "shap": shap.__version__},
        "n_train": int(len(X_train)), "n_test": int(len(X_test)),
    }
    (config.META_PATH).write_text(json.dumps(meta, indent=2, default=float))
    (config.REPORTS_DIR / "metrics.json").write_text(json.dumps(meta, indent=2, default=float))
    print(f"\nDone in {time.time() - t0:.0f}s. Model saved to {config.MODEL_PATH}")


if __name__ == "__main__":
    main()
