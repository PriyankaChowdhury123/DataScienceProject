# ChurnGuard AI — Customer Churn & Retention ROI Engine

Decision-automation capstone: predicts which telecom customers will leave, explains **why** (SHAP),
and converts predictions into **dollars** (which customers are worth an offer).

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python train.py            # downloads data, CV + tuning, saves model + reports (~5-15 min)
pytest -q                  # smoke tests
streamlit run app.py       # opens the executive app
```

## Project structure
```
app.py            Streamlit executive app (4 tabs)
train.py          End-to-end training / evaluation / SHAP / saving
src/config.py     Paths, seeds, default business assumptions
src/data.py       Load, clean, feature engineering, preprocessing pipeline
src/model.py      Candidate models, CV, tuning, evaluation, error analysis
src/roi.py        Cost model: predictions -> net benefit, threshold search
src/explain.py    SHAP helpers (global + per-customer, aggregated by feature)
tests/            pytest smoke tests
reports/          Generated plots, metrics.json, error analysis
docs/             Process guide, Q&A prep, presentation script
VIBE_CODING_LOG.md  1-page AI-workflow log (fill in!)
```

## Method in one paragraph
Stratified 80/20 split → scikit-learn `Pipeline` (feature engineering, imputation, scaling, one-hot) so
nothing leaks → 5-fold stratified CV over Dummy / Logistic Regression / Random Forest / XGBoost →
randomised hyper-parameter search optimising PR-AUC → profit-maximising decision threshold chosen on
**out-of-fold** training predictions → single evaluation on the untouched test set → SHAP explanations →
Streamlit app with live ROI calculator.

## Data
IBM Telco Customer Churn (public, 7,043 customers, 26.5% churn). `python train.py` downloads it
automatically to `data/telco_churn.csv`.

## Reproducibility
Fixed seed (`RANDOM_STATE = 42`), pinned in `src/config.py`; library versions saved in `models/metadata.json`.

## Results from our reference run (seed 42; yours should be very close)
| Item | Value |
|---|---|
| Selected model | XGBoost (tuned CV PR-AUC 0.663; Random Forest 0.663, Logistic Regression 0.662 — nearly tied) |
| Test ROC-AUC / PR-AUC | 0.847 / 0.656 (Dummy PR-AUC ≈ 0.265) |
| Business threshold | 0.46 → recall 0.82, precision 0.50 |
| Test-set net benefit | ≈ $43.1k vs $19.3k (contact everyone) vs $0 (do nothing), under default assumptions |

Defaults: CLV $800, offer cost $50, success rate 30% — **assumptions, not facts**; change them in `src/config.py` or the app sidebar.
