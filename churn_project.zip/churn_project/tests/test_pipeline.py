"""Smoke tests: pipeline runs on raw rows, no leakage, ROI math is right."""
import numpy as np
import pandas as pd
import pytest

from src import data, model, roi


@pytest.fixture(scope="module")
def split():
    return data.get_train_test()


def test_split_is_stratified(split):
    X_tr, X_te, y_tr, y_te = split
    assert abs(y_tr.mean() - y_te.mean()) < 0.01
    assert not set(X_tr.index) & set(X_te.index)          # no row overlap


def test_pipeline_predicts_on_raw_rows(split):
    X_tr, X_te, y_tr, _ = split
    pipe = model.make_pipeline(model.candidate_models(y_tr)["Logistic Regression"]).fit(X_tr, y_tr)
    p = pipe.predict_proba(X_te[data.RAW_INPUT_COLS])[:, 1]
    assert p.shape[0] == len(X_te) and ((p >= 0) & (p <= 1)).all()


def test_total_charges_blank_handled():
    df = pd.DataFrame([{**{c: "No" for c in data.ADDON_COLS}, "tenure": 0, "MonthlyCharges": 50.0,
                        "TotalCharges": " ", "PaymentMethod": "Mailed check"}])
    assert data.add_features(df).loc[0, "TotalCharges"] == 0


def test_roi_math():
    p = roi.CostParams(clv=1000, offer_cost=100, success_rate=0.5)
    y, pred = np.array([1, 1, 0, 0]), np.array([1, 0, 1, 0])
    assert roi.net_benefit(y, pred, p) == (0.5 * 1000 - 100) - 100   # 1 TP, 1 FP
