# Presentation Script (15 min + Q&A)

## Part A — Executive pitch (5:00)
| Time | Slide | Content |
|---|---|---|
| 0:00 | 1. Problem | Churn costs telecoms revenue; acquiring a customer costs more than keeping one. Show churn rate (26.5%) and cost per lost customer. |
| 1:00 | 2. Persona & pain | Head of Retention: can't tell whom to call. |
| 2:00 | 3. Solution | ChurnGuard: score → explain → recommend → value. Screenshot of app. |
| 3:00 | 4. ROI | Bar chart: do nothing / contact all / random / model (from the app's Business-impact tab). State assumptions. |
| 4:00 | 5. Go-to-market | Pilot with one segment → A/B test → roll out; pricing/ownership; risks. |

## Part B — Technical deep dive (10:00)
| Time | Slide | Content |
|---|---|---|
| 5:00 | 6. Architecture | Diagram: CSV → clean → split → Pipeline(features → prep → model) → threshold → SHAP → Streamlit |
| 6:00 | 7. Data & features | EDA highlights; engineered features; leakage controls |
| 7:00 | 8. Model comparison | CV table (mean ± std) vs Dummy baseline; why PR-AUC |
| 8:00 | 9. Tuning | Search spaces + best parameters; before/after |
| 9:00 | 10. Threshold & ROI | Net-benefit-vs-threshold curve |
| 10:00 | 11. Explainability | SHAP importance + one local example |
| 11:00 | 12. Error analysis | Segments with weaker recall; 2 misclassified examples; fixes |
| 12:00 | **Live demo** | High-risk customer → low-risk → batch sample → change ROI slider |
| 14:00 | 13. Limits & next steps | Drift, calibration, uplift modelling, fairness |
| 14:45 | 14. Summary | 3 take-aways |

## Demo checklist
- App already running; model loaded; browser zoom 110%.
- Three preset customers written down; backup screen recording ready.
- Assign one presenter per section; every member knows all sections.
