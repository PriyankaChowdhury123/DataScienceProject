# Individual Q&A Prep — "Under the Hood"
Every member should answer any of these in plain language, pointing to the code.

## Data & leakage
- **Why split before preprocessing?** Imputation values, scaling means and category lists are *learned*; learning them on test data leaks information. All fitting is inside the `Pipeline` (`src/data.py`), so CV refits per fold.
- **Why stratified split/CV?** Churn is 26.5%; stratification keeps that ratio in each fold so metrics are stable.
- **Why drop `gender`/`customerID`?** ID carries no signal; gender is a protected-style attribute — we avoid using it.
- **TotalCharges blanks?** 11 rows, all tenure 0 → replaced by tenure × monthly (= 0).
- **Why one-hot and `handle_unknown="ignore"`?** Models need numbers; unseen categories in production must not crash the app.
- **Why scale if trees don't need it?** Logistic regression does (regularisation is scale-sensitive); one shared pipeline is simpler.

## Models & parameters
- **Logistic regression:** linear model of log-odds; `C` = inverse L2 regularisation strength (small C = stronger shrinkage); we search `C` log-uniformly 1e-3…1e2 because its effect is multiplicative.
- **Random forest:** bagging of deep trees on bootstrap samples + random feature subsets; `max_depth`, `min_samples_leaf` control overfitting; `max_features` controls tree decorrelation.
- **XGBoost:** gradient boosting — each new shallow tree fits the gradient (errors) of the current ensemble. `learning_rate` shrinks each tree's contribution (lower = more trees needed); `max_depth` interaction order; `subsample`/`colsample_bytree` add randomness; `min_child_weight` and `reg_lambda` regularise; `scale_pos_weight = neg/pos` rebalances the loss.
- **Why compare to a Dummy?** It sets the floor: PR-AUC of a no-skill model equals the churn rate (~0.265).
- **Why is the simpler model sometimes just as good?** Tabular data with few strong signals (contract, tenure, charges); boosting's extra capacity adds little. Say so honestly — the simpler model is also more explainable.
- **Why random search?** Same quality as grid with far fewer fits; good when several parameters matter.

## Metrics & threshold
- **Why not accuracy?** Predicting "nobody churns" gives ~73.5% accuracy but zero value.
- **Precision/Recall/F1?** Precision = of those we flag, how many churn; recall = of churners, how many we catch; F1 = harmonic mean.
- **ROC-AUC vs PR-AUC?** ROC-AUC = probability a random churner is ranked above a random loyal customer; PR-AUC focuses on the positive class and is more honest under imbalance — we tune on it.
- **Why not threshold 0.5?** Costs are asymmetric (missing a churner vs wasting a $ offer). We pick the threshold maximising net dollars on out-of-fold training predictions (never on test).
- **Calibration?** Do predicted 30% risks churn ~30% of the time? Needed because the app multiplies probabilities by dollars.

## Explainability
- **SHAP in one line:** Shapley values from game theory — each feature's average marginal contribution to this prediction vs the baseline; additive in log-odds.
- **TreeExplainer vs LinearExplainer:** exact, fast algorithms for tree ensembles / linear models.
- **Why aggregate one-hot columns?** An executive thinks in "Contract", not "Contract_One year"; we sum SHAP back to the original feature.
- **SHAP vs LIME?** LIME fits a local surrogate on perturbed samples (approximate, unstable); SHAP has consistency guarantees. SHAP ≠ causation.

## Business
- **ROI formula:** net = TP × (success × CLV − offer cost) − FP × offer cost. Do-nothing = 0.
- **Weakest assumption?** Offer success rate and CLV → we expose them as sliders and show sensitivity.
- **Deployment risks?** Data drift, label delay, offer fatigue, fairness; mitigate with monitoring, retraining schedule, A/B test of the campaign.

## Engineering
- **Why a saved pipeline?** One object guarantees identical preprocessing in training and the app.
- **How do we reproduce results?** Fixed seed, pinned requirements, versions in `models/metadata.json`.
