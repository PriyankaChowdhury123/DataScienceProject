# Step-by-Step Process (what to do, in order)

## Phase 0 — Setup (Day 1)
1. Create the GitHub repo; each member clones it. Use branches + pull requests.
2. `python -m venv .venv`, `pip install -r requirements.txt`, run `python train.py` once so everyone has the artifacts.
3. Assign roles (8-9 people):
   | Role | Owns (and must defend) | Files |
   |---|---|---|
   | 1 Project lead / integrator | repo, timeline, final slides | whole repo |
   | 2-3 Business & ROI (2) | problem, persona, market, cost assumptions | `src/roi.py`, pitch slides |
   | 4-5 Data (2) | cleaning, features, leakage prevention | `src/data.py` |
   | 6-7 Modelling (2) | CV, tuning, metrics, threshold | `src/model.py`, `train.py` |
   | 8 Explainability & errors | SHAP, error analysis, fairness | `src/explain.py` |
   | 9 App & vibe log | Streamlit UX, demo, log, tests | `app.py`, `VIBE_CODING_LOG.md` |
4. Start the Vibe Coding Log immediately; add an entry whenever you use an AI tool.

## Phase 1 — Problem & business case (Days 1-3)
5. One-sentence problem: *"Retention managers lose revenue when customers churn unnoticed; ChurnGuard ranks customers by risk, explains why, and shows which offers pay back."*
6. Persona: Head of Customer Retention (non-technical; wants a list, a reason, and a dollar figure).
7. Edit `src/config.py` assumptions (CLV, offer cost, success rate). Justify each with an industry source or clearly-labelled estimate.
8. Define baselines: do nothing / contact everyone / random / model.

## Phase 2 — Data (Days 3-6)  `src/data.py`
9. EDA (notebook or `train.py` prints): shape, missing values, class balance (26.5% churn), distributions.
10. Clean: drop duplicates and ID, coerce `TotalCharges` (11 blanks, all tenure = 0), encode target.
11. Split FIRST (stratified 80/20). Test set is touched once, at the end.
12. Features: `avg_monthly_spend`, `charge_delta`, `num_addons`, `tenure_group`, `autopay`. `gender` excluded on purpose.
13. Preprocessing in a `Pipeline`: median impute + scale numerics; mode impute + one-hot categoricals (`handle_unknown="ignore"`).

## Phase 3 — Modelling (Days 6-10)  `src/model.py`, `train.py`
14. Dummy baseline, Logistic Regression, Random Forest, XGBoost — default parameters, 5-fold stratified CV, report mean ± std of ROC-AUC, PR-AUC, F1, recall, precision.
15. Imbalance: `class_weight` (LR/RF) and `scale_pos_weight` (XGB). No resampling outside CV.
16. Tune with `RandomizedSearchCV` (scoring = PR-AUC). Document every range.
17. Pick the best by CV PR-AUC. Get **out-of-fold** probabilities; choose the threshold that maximises net dollars.
18. Refit on full train; evaluate ONCE on test (ROC-AUC, PR-AUC, precision/recall/F1, Brier, confusion matrix, calibration).

## Phase 4 — Explainability & error analysis (Days 9-12)  `src/explain.py`
19. Global SHAP: beeswarm + business-feature bar chart.
20. Local SHAP: top drivers for one customer (shown in app).
21. Error analysis: `reports/error_by_segment.csv`, `reports/top_misclassified.csv`. Write 3 findings and 3 improvements.

## Phase 5 — App (Days 10-14)  `app.py`
22. `streamlit run app.py`. Tabs: Score a customer · Batch scoring · Business impact · Model performance.
23. Prepare 3 demo customers: (a) high risk — month-to-month, fiber, electronic check, tenure 2; (b) low risk — two-year contract, tenure 60; (c) borderline.
24. Dry-run on the presentation laptop; record a backup video.

## Phase 6 — Repo & log (Days 12-15)
25. `pytest -q` passes; fresh-clone test in a new virtual environment.
26. README accurate; `requirements.txt` installs cleanly.
27. Complete `VIBE_CODING_LOG.md` (1 page).

## Phase 7 — Presentation (Days 14-17)  see `docs/PRESENTATION_SCRIPT.md`
28. Slides: 5-min pitch + 10-min technical + live demo. Rehearse twice with a timer.

## Phase 8 — Individual Q&A (daily in last week)  see `docs/QA_PREP.md`
29. Mock Q&A: pick a random member + random question. Everyone must explain every module in plain words.

## Timeline
| Week | Focus |
|---|---|
| 1 | Setup, business case, EDA, data pipeline |
| 2 | Models, CV, tuning, threshold, ROI |
| 3 | SHAP, error analysis, app, tests |
| 4 | Log, slides, rehearsals, mock Q&A |

## Extension ideas (bonus depth)
SMOTE inside CV for comparison; calibration (`CalibratedClassifierCV`); fairness by senior/partner groups; LIME vs SHAP comparison; drift monitoring plan; Optuna instead of random search; uplift modelling (who responds to offers).
